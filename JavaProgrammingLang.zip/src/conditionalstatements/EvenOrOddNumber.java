package conditionalstatements;

public class EvenOrOddNumber {

	public static void main(String[] args) 
	{
	  // Check if number 10 is even or odd using if else condition
		
		int number=10;
		
		if(number%2==0)
		{
			System.out.println("number is even");
		}
		else
		{
			System.out.println("number is odd");
		}
		

		  // Check if number 11 is even or odd using if else condition
			
			int num=11;
			
			if(num%2==0)
			{
				System.out.println("number is even");
			}
			else
			{
				System.out.println("number is odd");
			}
 
	}

}
