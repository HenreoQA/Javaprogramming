package conditionalstatements;

public class PositiveNegativeZero {

	public static void main(String[] args) 
	{
		// Check if number 10 is positive, negative or zero using if else condition
		
		int number=10;
		
		if(number>0)
		{
			System.out.println("number is positive");
		}
		else
			if(number<0)
			{
				System.out.println("number is negative");
			}
			else
			{
				System.out.println("number is zero");
			}
		
		// Check if number -10 is positive, negative or zero using if else condition
		
				int num=-10;
				
				if(num>0)
				{
					System.out.println("number is positive");
				}
				else
					if(num<0)
					{
						System.out.println("number is negative");
					}
					else
					{
						System.out.println("number is zero");
					}
				
		// Check if number 0 is positive, negative or zero using if else condition
				
				int n=0;
				
				if(n>0)
				{
					System.out.println("number is positive");
				}
				else
					if(n<0)
					{
						System.out.println("number is negative");
					}
					else
					{
						System.out.println("number is zero");
					} 
					
					
			

	}

}
