
  // SUM OF ELEMENTS/VALUES IN ARRAY
 
 // Example1: Find the sum of elements/values in array where a=(1,2,3,4,5)
 
package day8;

public class SumOfElementsInArray {

	public static void main(String[] args) 
	{
		
		// Using for loop and single dimensional method
		
		/*int a[]= {1,2,3,4,5};
		
		int sum=0;
		
		for(int i=0; i<a.length; i++)
		{
			sum=sum+a[i];
		}
		System.out.println("Sum of the elements is:"+sum);*/
		
		// Using enhanced for loop
		
		/*int a[]= {1,2,3,4,5};
		
		int sum=0;
		
		for(int x:a)
		{
			sum=sum+x;
		}
		  System.out.println("Sum of the elements is:"+sum);*/
		
		
 // Example2: Find the sum of elements/values in array where a=(10,20,30,40)
		
		// Using enhanced for loop
		
		/*int a[] = {10,20,30,40};
		
		int sum=0;
		
		for(int y:a)
		{
			sum=sum+y;
		}
		 System.out.println("sum of the elements is:"+sum);*/
		 
	
		// Using for loop
		
		/*int a[] = {10,20,30,40};
		
		int sum=0;
		
		for(int i=0; i<a.length; i++)
		{
			sum=sum+a[i];
		}
		  System.out.println("Sum of the elements is:"+sum);*/


	}

}
