package day8;

public class LinearSearch {

	public static void main(String[] args) 
	{
		

	}

}
