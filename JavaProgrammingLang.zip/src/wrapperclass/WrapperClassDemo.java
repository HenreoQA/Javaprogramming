package wrapperclass;

public class WrapperClassDemo {

	public static void main(String[] args) 
	{
	//  Difference between primitive variable and wrapper variable:

 // We can't access the method using primitive variable while we can access the method through the 
 // object when we use wrapper variable/object variable.
		
		int a=100; // primitive variable
		System.out.println(a);
		a.
		
		Integer b=200; // wrapper variable
		b.intValue();
		
	}

}
