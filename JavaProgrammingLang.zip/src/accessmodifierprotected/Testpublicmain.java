package accessmodifierprotected;

import accessmodifiertypes.Testpublic;

public class Testpublicmain {

	public static void main(String[] args) 
	{
		Testpublic tp=new Testpublic (); // creating object
		tp.m4(); // calling public method

	}

}
