package multipleinheritanceusinginterface;

public interface ABC 
{
  int v=100; // static variable
  
  void m1(); // abstract method
}

