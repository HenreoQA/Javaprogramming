package multipleinheritanceusinginterface;

// Adding another parent class MNO to a child class MNOmain and then access the interface

public class MNO
{
	int i=300;
	
	void m3() 
	{
	  System.out.println("This is m3 from MNO");
	  System.out.println(i);
	}
	
	
}
