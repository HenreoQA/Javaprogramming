package multipleinheritanceusinginterface;

public interface XYZ 
{
	int u=200; // static variable
	
	void m2(); // abstract method

}
