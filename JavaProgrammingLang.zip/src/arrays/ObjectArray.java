
 // OBJECT TYPE OF AN ARRAY: Object is used when you have a variable that 
// contains different data types. eg, int a=12, String a="Hello", double a=10.5, 
 // boolean a=true, char a='A'

package arrays;

public class ObjectArray {

	public static void main(String[] args) 
	{
		   // Using enhanced for loop:
		
      /*    Object a[] = {12,10.5,"Hello",true,'A'};
		
		 for(Object x:a) 
		 {
			 System.out.println(x); 
		 }*/
		 
		 
		 /*Object a[][]= {{100,20.34},{"Welcome",true},{500,'A'}};
			
			for(Object x[]:a)
			{
				for(Object y:x)
				{
					System.out.println(y);
				}
			}*/
			
		
		 
		 
		 
		 
	}

}
