package loopingstatements;

public class WhileLoopVsDoWhileLoop {

	public static void main(String[] args) 
	{
		// Difference between while loop and do while loop:
		 
// 1.In while loop, the condition is checked before the execution of the 
// statement (top-down approach) while in do while loop, the statement is 
// executed at least once before the condition is checked (bottom-up approach).
		
		// Example1: Print numbers 10-1 in descending order
		
		// for while loop
		
	/*	int i=10;
		
		while(i<=5)
		{
			System.out.println(i);
			i--;
		} */
		
		// for do while loop,
		
     /*    int i=10;
		 
         do
		{
			System.out.println(i);
			i--;
		}
		while(i<=5); */
		
		

	}

}
