package datatypes;

public class DataTypesDemo2 {

	public static void main(String[] args) 
	{
	
	//Numerical data types: Used for whole numbers. They are int, byte, short, long
		
	/*int v=1298678;
	long x=1234567789;
	short y=12378;
	byte z=120;*/
	
	//System.out.println("the value of v is:"+v);
	//System.out.println("the value of x is:" +x);
	//System.out.println("the value of y is:" +y);
	//System.out.println("the value of z is:" +z);
		
	//Decimal data types: Used for decimal numbers. They are float, double
		
		//float item=10.123456f;
		//System.out.println("the value of item is:"+item);
		
		//float items=29.4567F;
		//System.out.println("the value of item is:"+items);
		
		//double price=30.789456782345674;
		//System.out.println("the value of price is:"+price);
		
	//Single character data type: Used to store single xter/letter. eg, char
		
		//char grade='A';   //char is represented with single quotation while string is represented with double quotation
		//System.out.println("the grade of the student is:"+grade);
		
	//True or False data type: Used to store true/false values. eg, boolean
		
		//boolean bu=true; 
		//System.out.println("It is "+bu);
		
		//boolean f=false; 
		//System.out.println("It is "+f);
		
	//String name="John";
		//System.out.println("His name is" +name);
		
		
		
		
		
		
		
		
		
		

	}

}
