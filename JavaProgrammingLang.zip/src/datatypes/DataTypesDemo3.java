package datatypes;

public class DataTypesDemo3 {

	public static void main(String[] args) 
	{
	   /*int a=10;
       short b=16738;
	   long c=23897444;
	   byte d=120;
	   float e=37.976f;
	   double f=23.735474863;
	   char grade='B';
	   boolean g=true;
	   String name="Mike";*/
	   
	  /*System.out.println(a);
	  System.out.println(b);
	  System.out.println(c);
	  System.out.println(d);
	  System.out.println(e);
	  System.out.println(f);
	  System.out.println(grade);
	  System.out.println(g);
	  System.out.println(name);*/
			
	 
	   
			
	
		
		
		
		
		
		

	}

}
