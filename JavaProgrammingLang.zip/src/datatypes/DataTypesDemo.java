package datatypes;

public class DataTypesDemo 
{

	public static void main(String[] args)
	{
		//Numerical data type: //Variable cannot have more than one data type or duplicated
		
		/* int a;     //declaration or creation of variable
		a=100;     //assignment or assigning data to the variable
		//To print the values, use
		System.out.println(a);*/
		
		//For Variable in a single line or statement:
		
		/*int b=200;
		System.out.println(b);*/
		
		//For Variables in multiple lines or statements:
		
		//Approach1 - Used if variable have different or the same data type
		/*int a=100;
		char b= 'A';
		String c="John";*/
		
		/*int g=6; 
		int p=8; 
		int y=9;
		System.out.println(g+y+p);*/
		
		/*int w=7; char n='F'; String name="john"; boolean v=true;*/
		
		//Approach2 - Used if the variables have the same data type
	    /*int a,b,c;
		a=100;
		b=200;
		c=300;*/
		
		//Approach3 -  Used if the variables have the same data type
		/* int a=100,b=200,c=300;*/
		
		/*System.out.println(a);
		System.out.println(b);
		System.out.println(c);*/
		
		//System.out.println(a+b+c);
		//System.out.println(a*b*c);
		//System.out.println(a-b-c);
	    //System.out.println(a+" "+b+" "+c);     //cancat
		
		//System.out.println("the value of a ="+a);
		//System.out.println("the value of b ="+b);
		//System.out.println("the value of c ="+c);
		//System.out.println("The value of a is:"+a);
		
		/*int k=34;
		k=56; //the value of the variable can be changed without adding the data type to the variable again
		System.out.println(k);*/
		
		

		
		
		
		
		
		
		


	}

}
