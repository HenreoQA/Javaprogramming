package method;

public class GreetingsMainClass 


{

	public static void main(String[] args) 
	{
		// 1. No parameters, no return values
	 
	/*  Greetings gr=new Greetings(); // creating the object
		
	 gr.greeting1(); */ // calling the method through object
	
	 
	// 2. No parameters, return values
		
	/*  Greetings gr=new Greetings();
	 
	 System.out.println(gr.greeting2());
	 
	 System.out.println(gr.greeting3());
	 
	 System.out.println(gr.greeting4());
		
	 System.out.println(gr.greeting5());
	 
	 System.out.println(gr.greeting6());
	 
	 System.out.println(gr.greeting7()); */
		
	
	// 3. Take parameters, No return of values
		
	/* Greetings gr=new Greetings();
	
	gr.greeting8("Hello John");
	
	gr.greeting9(123); */
	
		
		
 // 4. Take parameters, return of values	
		
  /*	Greetings gr=new Greetings();
		
	System.out.println(gr.greeting10("John"));
		
	System.out.println(gr.greeting11(246));  */
	
	 
	 
	 

	}

}
