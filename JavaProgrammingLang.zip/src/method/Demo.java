package method;

public class Demo 
{
	int u=20;
	
	void display()
	{
		System.out.println(u);
	}

	
	public static void main(String[] args) 
	{
		Demo de=new Demo();
		
		de.display();

	}

}
