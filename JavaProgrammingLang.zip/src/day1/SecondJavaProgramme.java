package day1;

public class SecondJavaProgramme 
{

	public static void main(String[] args) 
	{
		//System.out.println("welcome to Java Class");
		System.out.println("welcome to Java Class");
		System.out.println("welcome to Java Class");
		System.out.println("welcome to Java Class");
		System.out.println(10*12);
		

	}

}
