package day1;

public class MyFirstJavaProgramme 

{

public static void main (String args[])
{
	System.out.println(10+20);
	
	//Syso+Ctl+space  ---- Short form to type System.out.println();
	
System.out.println(20);




}


}

