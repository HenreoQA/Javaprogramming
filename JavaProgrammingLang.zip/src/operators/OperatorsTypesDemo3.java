package operators;

public class OperatorsTypesDemo3 

{

	public static void main(String[] args) 
	
	{
		// 5. Assignment operators: It is used to increase or decrease the values by more than one. 
		// eg, =  +=  -=  *=  /=  %=
		
		// = is purely assignment operator
		// += -= *= /= %= can be called assignment or short hand operators
		
		// +=  used to increase values by more than one
		// -=  used to decrease values by more than one	
		
		// Increment by more than one - example
		
	//	int a=10;
	// 	a=a+5;
	//	System.out.println(a); */ // ---- 15
		
	//	a+=5;
	//	System.out.println(a); // --- 15
		
		// Decrement by more than one - example
		
	//	int b=20;
	//	b=b-10;
	//	System.out.println(b); // --- 10
		
	//    b-=10;
	//	System.out.println(b); // --- 10
		
		// *= /= %=
		
	//	int h=10;
	//	h=h*2;
	//	System.out.println(h); // --- 20
		
	//	h*=2;
	//    System.out.println(h); // --- 20
		
	//	int d=5;
	//	d=d/2;
	//	System.out.println(d); //--- 2 (return the quotient)
		
	//	d/=2;
	//	System.out.println(d); // --- 2 (return the quotient)
		
	//	int p=7;
	//	p=p%2;
	//    System.out.println(p); // --- 1 (return the remainder)
		
	//	p%=2;
	//	System.out.println(p); // --- 1 (return the quotient)
		
		
	

	}

}
