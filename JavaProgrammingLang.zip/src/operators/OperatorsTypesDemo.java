package operators;

public class OperatorsTypesDemo {

	public static void main(String[] args) 
	{
		//TYPES OF OPERATORS:
		
	// 1. Arithmetic operators:Perform arithmetic operations. eg, +  -  *  /  %
		
	/*  int a=20, b=11;
		System.out.println("Sum of a and b is:"+(a+b));
		System.out.println("Difference of a and b is:"+(a-b));
		System.out.println("Multiplication of a and b is:"+(a*b));
		System.out.println("Division of a and b is:"+(a/b));  //Division returns the quotient
		System.out.println("Modulo division of a and b is:"+(a%b));*/ //modulo division returns remainder value after quotient

    // 2. Relational/comparison operators: It is used to compare two variables/values or expressions. 
		//It is used on strings, numerical values. It returns a boolean value (ie true or false value). 
		//eg, >  >=  <  <=  !=  ==
		
	  /*  int x=30, y=10;
		System.out.println("Is x greater than y:"+(x>y));
		System.out.println(x>=y);
		System.out.println(x<y);
		System.out.println(x<=y);
		System.out.println(x!=y);
		System.out.println(x==y); */
	
	// 3. Logical operators: It is only used between two or more boolean values.
		//It returns true or false values/variables. 
		//eg, &&  ||  !
		
	/*	boolean b1=true, b2=false;
		System.out.println(b1 && b2);
		System.out.println(b1 || b2);
		System.out.println(!b1);
		System.out.println(!b2); */
		
	/*	boolean b3=40>20, b4=10<5;
		System.out.println(b3 && b4);
		System.out.println(b3 || b4);
		System.out.println(!b3);
		System.out.println(!b4); */
		

		
		

		
		
	
		

		
		

	}

}
