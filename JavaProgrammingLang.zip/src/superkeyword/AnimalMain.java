package superkeyword;

public class AnimalMain {

	public static void main(String[] args) 
	{
		dog d=new dog();
		d.displaycolour();
		d.eat();
		
		
		 
	

	}

}
 