package constructor;

public class ConstructorDemo 
{
     /* int x,y;
     String s;
     
     ConstructorDemo() // default constructor because it is not taking any parameter
     {
    	 x=100;
    	 y=200;
    	 s= "welcome";
     }
     
     void display()
     {
    	 System.out.println(x);
    	 System.out.println(y);
    	 System.out.println(s);
     } */
	
	
  /*	public static void main(String[] args) 
	{
		ConstructorDemo cd=new ConstructorDemo(); // invoking/calling default constructor
		
		cd.display();  // calling the method

	}*/
	
	
	  /* int x,y;
	   String s="welcome";
	   
	   ConstructorDemo(int a, int b, String z) // This is called parameterized constructor because it takes parameters
	   {
		  x=a;
		  y=b;
		  s=z;
	   }
	   
	   void display()
	     {
	    	 System.out.println(x);
	    	 System.out.println(y);
	    	 System.out.println(s);
	     }
	   
	   public static void main(String[] args) 
		{
			ConstructorDemo cd=new ConstructorDemo(100,200,"welcome"); // invoking/calling parameterised constructor
			
			cd.display(); // calling the method

		}*/
	   
	   
	   
	   
	

}
