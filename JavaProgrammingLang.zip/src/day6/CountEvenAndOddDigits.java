package day6;

public class CountEvenAndOddDigits {

	public static void main(String[] args) 
	{
	  // Count number of even and odd digits in a number 24567
		
		/*int num=24567;
		
		int even_count=0;
		int odd_count=0;
		
		while(num>0)
		{
			int rem=num%10;
			if(num%2==0)
			{
			    even_count++;
			}
			else
			{
				 odd_count++;
			}
			num=num/10;
			
		}
		System.out.println("Number of even numbers:"+even_count);
		System.out.println("Number of even numbers:"+odd_count);*/
		
		
		  
		
		

	}

}
