package day6;

public class CountSumOfDigits {

	public static void main(String[] args) 
	{
		// Example 1:Find sum of digits in a number 1234
		
		/*int num=1234;
		
		int sum=0;
		
		while(num>0)
		{
			sum=sum+num%10;
			num=num/10;
		}
		System.out.println("Sum of digits in a number:"+sum);*/
		
		// Example 2: Find the sum of digits in a number 2468
		
		/*int num=2468;
		
		int sum=0;
		
		while(num>0)
		{
			sum=sum+num%10;
			num=num/10;
		}
		System.out.println("Sum of digits is:"+sum);*/
		
		
		
		
		
		
		
		
		
		 
		

	}

}
