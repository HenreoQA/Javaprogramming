package day6;

public class CountNumberOfDigits {

	public static void main(String[] args) 
	{
		// Count number of digits in a number 123456
		
		/*int num=123456;
		
		int count=0;
		
		while(num>0)
		{
			num=num/10;
			count++;
		}
		
		System.out.println("Number of digits is:"+count);*/
		

	}

}
