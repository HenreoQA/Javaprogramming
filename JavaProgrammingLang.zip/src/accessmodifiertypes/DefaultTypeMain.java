package accessmodifiertypes;

public class DefaultTypeMain {

	public static void main(String[] args) 
	{
		DefaultType d=new DefaultType (); // creating object
		d.m2(); // calling the default method
		d.m3();

	}

}
