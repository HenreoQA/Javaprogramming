package accessmodifiertypes;

public class Testpublic 
{
 // Public: Variables and methods can be accessed everywhere without using inheritance concept.
	 
		 public int x=400;
			
		 public void m4()
		{
			System.out.println("This is m4 method");
			System.out.println(x);
		}
}
